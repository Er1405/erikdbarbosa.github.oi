import './App.css'
import Inicio from './page/Inicio/Inicio'
import { Routes,Route } from 'react-router-dom'

function App() {
  

  return (
    <>
   <Routes>
  <Route path="/" element={< Inicio/>} />
</Routes>

    </>
  )
}

export default App
