import { Link } from "react-router-dom";

const Inicio = () => {
  return (
    <>
      <div>
        <Link to="/Matematica">Matematica</Link>
        <Link to="/Informatica">Informatica</Link>
        <Link to="/Humanas">Humanas</Link>
        <Link to="/Natureza">Natureza</Link>
        <div>
          <h1>Erik Douglas Barbosa Lago</h1>
          <p>ola</p>
        </div>
        <img src="" alt="" />
      </div>
    </>
  );
};

export default Inicio;
