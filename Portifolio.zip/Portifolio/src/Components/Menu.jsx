import { Link } from "react-router-dom";

const Menu = () => {
  return (
    <nav>
      <Link to="/"></Link>
      <Link to="/"></Link>
      <Link to="/"></Link>
    </nav>
  );
};

export default Menu;
